<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\VisualMerchandiser\Test\Unit\Model\Sorting;

use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\DB\Select;

class SpecialPriceBottomTest extends \PHPUnit\Framework\TestCase
{
    /**
     * @var \Magento\VisualMerchandiser\Model\Sorting\SpecialPriceBottom
     */
    private $model;

    protected function setUp()
    {
        $objectManagerHelper = new ObjectManager($this);
        $this->model = $objectManagerHelper->getObject(
            \Magento\VisualMerchandiser\Model\Sorting\SpecialPriceBottom::class,
            []
        );
    }

    public function testSort()
    {
        $collectionMock = $this->getMockBuilder(\Magento\Catalog\Model\ResourceModel\Product\Collection::class)
            ->disableOriginalConstructor()
            ->getMock();
        $connection = $this->getMockBuilder(\Magento\Framework\DB\Adapter\AdapterInterface::class)
            ->getMockForAbstractClass();
        $select = $this->getMockBuilder(\Magento\Framework\DB\Select::class)
            ->disableOriginalConstructor()
            ->getMock();
        $collectionMock->expects($this->any())->method('getConnection')->willReturn($connection);
        $collectionMock->expects($this->any())->method('getSelect')->willReturn($select);
        $select->expects($this->once())->method('getPart')->willReturn([]);
        $connection->expects($this->once())->method('getLeastSql');
        $connection->expects($this->once())->method('getCheckSql');
        $select->expects($this->once())->method('group')->with('entity_id')->willReturnSelf();
        $select->expects($this->once())->method('reset')->with(Select::ORDER)->willReturnSelf();
        $select->expects($this->once())->method('order')->willReturnSelf();
        $select->expects($this->once())->method('joinLeft')->willReturnSelf();
        $this->model->sort($collectionMock);
    }
}
