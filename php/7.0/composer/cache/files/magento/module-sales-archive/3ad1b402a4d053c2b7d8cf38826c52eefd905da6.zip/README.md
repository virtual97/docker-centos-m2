# Overview
## Purpose of module

Magento\SalesArchive module responsible for creating logical partitions for storing previews of orders, invoices, credit memos, shipments.
Primary purpose of this module is to increase performance for read operation on orders (shipments, credit memos, shipments) grid.