/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

require([
    'Magento_Variable/variables',
    'mage/adminhtml/browser'
]);
