Magento\AdvancedCatalog module introduces list of optimizations to allow higher concurrency on product management
operations with immediate update of product data on frontend and plays as an extension to indexation logic of
Magento\Catalog module.
