Magento\PersistentHistory module extends functionality of Magento\Persistent by providing ability to keep track of
products added to  wishlist, recently ordered items, currently compared products, comparison history, recently viewed
products and customer group membership and segmentation.