Magento_PricePermissions module allows to restrict such admin rights as changing or reading product price, changing product status.
