# AdminGws

**AdminGws** provides configuration management within the Global, Website, and Store data scopes. Restrictions can be 
imposed on various system elements through configurations that are applied at the desired level.
