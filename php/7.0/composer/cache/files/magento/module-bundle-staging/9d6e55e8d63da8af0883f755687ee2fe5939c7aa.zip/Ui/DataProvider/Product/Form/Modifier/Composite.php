<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\BundleStaging\Ui\DataProvider\Product\Form\Modifier;

/**
 * Class Composite
 * @package Magento\BundleStaging\Ui\DataProvider\Product\Form\Modifier
 */
class Composite extends \Magento\Bundle\Ui\DataProvider\Product\Form\Modifier\Composite
{

}
