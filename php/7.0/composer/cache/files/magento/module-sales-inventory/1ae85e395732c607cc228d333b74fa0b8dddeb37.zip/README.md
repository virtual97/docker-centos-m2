Magento_SalesInventory module allows retrieve and update stock attributes related to Magento_Sales, such as status and quantity.
