<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

return [
    '_website' => 'website1',
    '_email' => 'test1email.com',
    '_finance_website' => 'website2',
    'store_credit' => 10.5,
    'reward_points' => 5
];
