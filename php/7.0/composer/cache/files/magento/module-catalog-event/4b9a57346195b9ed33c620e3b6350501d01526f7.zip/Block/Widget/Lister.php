<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Catalog Event Widget
 *
 */
namespace Magento\CatalogEvent\Block\Widget;

class Lister extends \Magento\CatalogEvent\Block\Event\Lister implements \Magento\Widget\Block\BlockInterface
{
}
