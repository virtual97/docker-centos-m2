<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\CatalogEvent\Test\Unit\Controller\Adminhtml\Catalog\Stub;

class EventStub extends \Magento\CatalogEvent\Controller\Adminhtml\Catalog\Event
{
    public function execute()
    {
        // Empty method stub for test
    }
}
