AdvancedSearch module introduces advanced search functionality and provides interfaces that allow to implement this functionality by 3rd party search engines
