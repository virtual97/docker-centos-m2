<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\MultipleWishlist\Controller;

/**
 * Interface \Magento\MultipleWishlist\Controller\IndexInterface
 *
 */
interface IndexInterface extends \Magento\Wishlist\Controller\IndexInterface
{
}
