<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\CatalogStaging\Controller\Adminhtml\Product;

class Reload extends \Magento\Catalog\Controller\Adminhtml\Product\Reload
{

}
