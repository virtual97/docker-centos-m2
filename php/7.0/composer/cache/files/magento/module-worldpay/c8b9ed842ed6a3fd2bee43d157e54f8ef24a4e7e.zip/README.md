The Magento_Worldpay module implements the integration with the Worldpay payment gateway and makes the latter available as a payment method in Magento.
