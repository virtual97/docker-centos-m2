Magento\Version Allows to get Magento version and edition by HTTP GET request
