The Magento_Cybersource module implements the integration with the Cybersource payment gateway and makes the latter available as a payment method in Magento.
