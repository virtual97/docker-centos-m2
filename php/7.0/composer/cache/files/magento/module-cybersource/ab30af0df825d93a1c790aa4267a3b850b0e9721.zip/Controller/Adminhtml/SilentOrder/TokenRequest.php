<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Cybersource\Controller\Adminhtml\SilentOrder;

class TokenRequest extends \Magento\Cybersource\Controller\SilentOrder\TokenRequest
{

}
