<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\CatalogEvent\Test\Handler\CatalogEventEntity;

use Magento\Mtf\Handler\HandlerInterface;

/**
 * Interface CatalogEventEntityInterface
 */
interface CatalogEventEntityInterface extends HandlerInterface
{
    //
}
