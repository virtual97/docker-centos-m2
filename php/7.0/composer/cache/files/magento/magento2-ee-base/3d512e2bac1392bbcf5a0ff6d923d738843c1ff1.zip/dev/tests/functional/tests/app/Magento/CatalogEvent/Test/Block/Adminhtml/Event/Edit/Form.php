<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\CatalogEvent\Test\Block\Adminhtml\Event\Edit;

use Magento\Mtf\Block\Form as AbstractForm;

/**
 * Class Form
 * Catalog Event form
 */
class Form extends AbstractForm
{
    //
}
