<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\AdvancedCheckout\Test\Block\Customer;

/**
 * Customer Order By SKU form.
 */
class Sku extends \Magento\AdvancedCheckout\Test\Block\Sku\AbstractSku
{
    //
}
