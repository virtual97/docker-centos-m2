<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\CustomerSegment\Test\Block\Adminhtml\Customersegment\Edit\Tab;

use Magento\Backend\Test\Block\Widget\Tab;

/**
 * Class General
 * Customer segment form block
 */
class General extends Tab
{
    //
}
