<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\CustomerBalance\Test\Handler\CustomerBalance;

use Magento\Mtf\Handler\HandlerInterface;

/**
 * Interface CustomerBalanceInterface
 */
interface CustomerBalanceInterface extends HandlerInterface
{
    //
}
