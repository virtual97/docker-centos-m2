<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Banner\Test\Block\Adminhtml\Banner;

use Magento\Backend\Test\Block\Widget\FormTabs;

/**
 * Class BannerForm
 * Backend banner form
 */
class BannerForm extends FormTabs
{
    //
}
