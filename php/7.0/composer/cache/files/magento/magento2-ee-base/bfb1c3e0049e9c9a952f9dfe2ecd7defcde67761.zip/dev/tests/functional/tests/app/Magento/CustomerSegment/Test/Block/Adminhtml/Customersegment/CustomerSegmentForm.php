<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\CustomerSegment\Test\Block\Adminhtml\Customersegment;

use Magento\Backend\Test\Block\Widget\FormTabs;

/**
 * Class CustomerSegmentForm
 * Form for creation of the customer segment
 */
class CustomerSegmentForm extends FormTabs
{
    //
}
