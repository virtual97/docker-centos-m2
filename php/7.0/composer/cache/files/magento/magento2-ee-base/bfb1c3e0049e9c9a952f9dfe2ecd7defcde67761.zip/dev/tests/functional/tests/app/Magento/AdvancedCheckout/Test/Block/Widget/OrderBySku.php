<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\AdvancedCheckout\Test\Block\Widget;

/**
 * Order By SKU widget form.
 */
class OrderBySku extends \Magento\AdvancedCheckout\Test\Block\Sku\AbstractSku
{
    //
}
