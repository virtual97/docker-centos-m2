<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\CustomerBalance\Test\Fixture\CustomerBalance;

/**
 * Prepare WebsiteId for Customer Balance.
 */
class WebsiteId extends \Magento\Store\Test\Fixture\StoreGroup\WebsiteId
{
    //
}
