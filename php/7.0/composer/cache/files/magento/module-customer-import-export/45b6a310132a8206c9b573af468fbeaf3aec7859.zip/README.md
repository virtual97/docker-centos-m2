The Magento_CustomerImportExport module handles the import and export of the customers data and related addresses.
