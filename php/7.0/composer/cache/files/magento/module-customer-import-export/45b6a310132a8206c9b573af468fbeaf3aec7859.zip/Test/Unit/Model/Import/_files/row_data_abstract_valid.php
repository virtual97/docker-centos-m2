<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

return ['_website' => 'website1', '_email' => 'test1@email.com'];
