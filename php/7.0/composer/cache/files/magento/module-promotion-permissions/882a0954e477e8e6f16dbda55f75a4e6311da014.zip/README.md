Magento\PromotionPermission module provides the possibility to an admin user to manage access of promotions and product
prices in the Admin Panel. An admin user can set the following access rights for promotions and product prices: edit,
read, without any permissions.