 This component is designed to manage logical foreign keys on the application level for entities that are declared in different databases/database servers.
