The Magento_GiftCardAccount module is responsible for gift card balances, for both gift cards created by a store administrator and gift cards sold as gift card products.
