Magento_GiftCardImportExport module introduces import and export form GiftCard Product.
This module extends existing functionality of Magento_CatalogImportExport module by adding new product type.
