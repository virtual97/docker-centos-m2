Magento\AdvanceCheckout extends Magento_Checkout with following functions: adding product to cart by entering SKU on
frontend, uploading list of SKUs to add products to cart on frontend and ability for admin to manage customer's shopping
cart.