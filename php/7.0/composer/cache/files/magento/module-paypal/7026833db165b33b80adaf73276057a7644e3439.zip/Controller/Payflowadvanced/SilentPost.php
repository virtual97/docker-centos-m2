<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Paypal\Controller\Payflowadvanced;

class SilentPost extends \Magento\Paypal\Controller\Payflow\SilentPost
{
}
