Magento_TargetRule module allows to configure the rules for showing related products.
