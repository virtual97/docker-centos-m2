<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Acl resource
 */
namespace Magento\Framework\Acl;

/**
 * @api
 */
class AclResource extends \Zend_Acl_Resource
{
}
