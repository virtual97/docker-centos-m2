Magento_Solr module allows to use Solr search engine for product searching capabilities.
The module implements Magento_Search library interfaces.