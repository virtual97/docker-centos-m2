Magento_Support module is used for generation of system reports, which provide detailed information about the system environment and Magento instance configuration.
