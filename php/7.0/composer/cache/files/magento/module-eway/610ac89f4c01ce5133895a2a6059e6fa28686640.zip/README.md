The Magento_Eway module implements the integration with the Eway payment gateway and makes the latter available as a payment method in Magento.
