<?
/**
 * Some class description here.
 */
class ShortOpenTagDocblock {}
