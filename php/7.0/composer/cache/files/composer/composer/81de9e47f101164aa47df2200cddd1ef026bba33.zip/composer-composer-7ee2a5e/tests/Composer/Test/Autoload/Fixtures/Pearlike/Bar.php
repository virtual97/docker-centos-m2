<?php

class Pearlike_Bar
{
    public static $loaded = true;
}
