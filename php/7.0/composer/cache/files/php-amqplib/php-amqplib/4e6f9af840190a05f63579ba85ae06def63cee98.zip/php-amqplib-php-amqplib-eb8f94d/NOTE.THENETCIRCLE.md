## NOTE ##

This library is a fork of the [php-amqplib](http://code.google.com/p/php-amqplib/) library.

At The Netcircle we modified that library in order to work with PHP 5.3 Strict.

Also we improved the debug method to increase performance.

We use it daily in prod for sending/consuming 600K + messages per day.
