<?php

define('HOST', 'localhost');
define('PORT', 5672);
define('USER', 'phpamqplib');
define('PASS', 'phpamqplib_password');
define('VHOST', 'phpamqplib_testbed');
define('AMQP_DEBUG', false);
