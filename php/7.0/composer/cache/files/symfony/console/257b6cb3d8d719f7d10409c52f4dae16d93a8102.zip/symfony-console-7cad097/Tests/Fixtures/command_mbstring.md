descriptor:åèä
--------------

* Description: command åèä description
* Usage:

  * `descriptor:åèä [-o|--option_åèä] [--] <argument_åèä>`
  * `descriptor:åèä -o|--option_name <argument_name>`
  * `descriptor:åèä <argument_name>`

command åèä help

### Arguments:

**argument_åèä:**

* Name: argument_åèä
* Is required: yes
* Is array: no
* Description: <none>
* Default: `NULL`

### Options:

**option_åèä:**

* Name: `--option_åèä`
* Shortcut: `-o`
* Accept value: no
* Is value required: no
* Is multiple: no
* Description: <none>
* Default: `false`
