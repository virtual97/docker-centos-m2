<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\Prototype\Sub;

class Bar
{
}
