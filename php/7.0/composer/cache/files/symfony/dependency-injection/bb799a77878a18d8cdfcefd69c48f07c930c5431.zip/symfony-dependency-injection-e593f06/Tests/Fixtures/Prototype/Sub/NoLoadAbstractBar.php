<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\Prototype\Sub;

abstract class NoLoadAbstractBar
{
}
