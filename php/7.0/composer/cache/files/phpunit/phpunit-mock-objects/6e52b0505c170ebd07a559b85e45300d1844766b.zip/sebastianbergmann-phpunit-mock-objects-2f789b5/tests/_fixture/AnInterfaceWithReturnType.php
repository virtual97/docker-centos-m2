<?php
interface AnInterfaceWithReturnType
{
    public function returnAnArray(): array;
}
