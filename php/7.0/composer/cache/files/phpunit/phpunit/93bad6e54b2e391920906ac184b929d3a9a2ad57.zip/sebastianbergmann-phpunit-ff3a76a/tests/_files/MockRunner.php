<?php
use PHPUnit\Runner\BaseTestRunner;

class MockRunner extends BaseTestRunner
{
    protected function runFailed($message)
    {
    }
}
