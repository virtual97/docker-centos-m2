# Changelog

All notable changes to this project will be documented in this file, in reverse chronological order by release.

## 2.6.0 - 2016-02-08

### Added

- [#10](https://github.com/zendframework/zend-text/pull/10) adds and publishes
  documentation; view it at https://zendframework.github.io/zend-text/

### Deprecated

- Nothing.

### Removed

- Nothing.

### Fixed

- [#2](https://github.com/zendframework/zend-text/pull/2) and
  [#9](https://github.com/zendframework/zend-text/pull/9) update the component
  to be forwards-compatible with zend-servicemanager v3.
