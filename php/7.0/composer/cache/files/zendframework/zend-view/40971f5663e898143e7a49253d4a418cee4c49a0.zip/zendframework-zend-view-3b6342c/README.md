# zend-view

[![Build Status](https://secure.travis-ci.org/zendframework/zend-view.svg?branch=master)](https://secure.travis-ci.org/zendframework/zend-view)
[![Coverage Status](https://coveralls.io/repos/zendframework/zend-view/badge.svg?branch=master)](https://coveralls.io/r/zendframework/zend-view?branch=master)

zend-view provides the “View” layer of the Zend Framework MVC system. It is a
multi-tiered system allowing a variety of mechanisms for extension,
substitution, and more.

- File issues at https://github.com/zendframework/zend-view/issues
- Documentation is at https://zendframework.github.io/zend-view/
