# zend-serializer

[![Build Status](https://secure.travis-ci.org/zendframework/zend-serializer.svg?branch=master)](https://secure.travis-ci.org/zendframework/zend-serializer)
[![Coverage Status](https://coveralls.io/repos/zendframework/zend-serializer/badge.svg?branch=master)](https://coveralls.io/r/zendframework/zend-serializer?branch=master)

zend-serializer provides an adapter-based interface for generating and
recovering from storable representations of PHP types.

- File issues at https://github.com/zendframework/zend-serializer/issues
- Documentation is at https://zendframework.github.io/zend-serializer/
