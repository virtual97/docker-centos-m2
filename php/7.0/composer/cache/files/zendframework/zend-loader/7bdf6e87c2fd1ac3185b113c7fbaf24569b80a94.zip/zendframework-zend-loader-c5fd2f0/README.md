# zend-loader

[![Build Status](https://secure.travis-ci.org/zendframework/zend-loader.svg?branch=master)](https://secure.travis-ci.org/zendframework/zend-loader)
[![Coverage Status](https://coveralls.io/repos/zendframework/zend-loader/badge.svg?branch=master)](https://coveralls.io/r/zendframework/zend-loader?branch=master)

`Zend\Loader` provides different strategies for autoloading PHP classes.


- File issues at https://github.com/zendframework/zend-loader/issues
- Documentation is at http://framework.zend.com/manual/current/en/index.html#zend-loader
