# zend-console

[![Build Status](https://secure.travis-ci.org/zendframework/zend-console.svg?branch=master)](https://secure.travis-ci.org/zendframework/zend-console)
[![Coverage Status](https://coveralls.io/repos/zendframework/zend-console/badge.svg?branch=master)](https://coveralls.io/r/zendframework/zend-console?branch=master)

`Zend\Console` is a component to design and implement console applications in PHP.


- File issues at https://github.com/zendframework/zend-console/issues
- Documentation is at http://framework.zend.com/manual/current/en/index.html#zend-console
