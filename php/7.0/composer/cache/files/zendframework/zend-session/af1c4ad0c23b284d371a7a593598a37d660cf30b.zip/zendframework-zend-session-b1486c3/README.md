# zend-session

[![Build Status](https://secure.travis-ci.org/zendframework/zend-session.svg?branch=master)](https://secure.travis-ci.org/zendframework/zend-session)
[![Coverage Status](https://coveralls.io/repos/zendframework/zend-session/badge.svg?branch=master)](https://coveralls.io/r/zendframework/zend-session?branch=master)

zend-session manages PHP sessions using an object oriented interface. 

- File issues at https://github.com/zendframework/zend-session/issues
- Documentation is at https://zendframework.github.io/zend-session/
