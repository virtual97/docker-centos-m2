<?php
/**
 * Copyright 2017 Shopial. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Shopial_Facebook',
    __DIR__
);
