# Magento_ShopialFacebook module

## Overview

Shopial_Facebook module enable you to sell and promote their products in Facebook. 
The integration is very simple and it enable your customers to purchase your products through Facebook while the module is taking care for the synchronization between your original store and you Facebook store.
You will be able to create 



## Installation details

The Shopial_Facebook module create a new user integration that called Magento Social which has permission to the Magento_Catalog::products. 
In order to complete the integration the user need to manually enter to the Integration tab under System and Activate this user. 
After then, there is a new tab that called Magento Social under Marketing that continue the installation on the Facebook business page side.



### UI components

The Shopial_Facebook module provide UI component under Marketing which called Magento Social and enable the abilities to redirect to the Integration tab and continue the installation process outside of the Magento environment. 
It also contain some information about how to activate the integration user as well.

