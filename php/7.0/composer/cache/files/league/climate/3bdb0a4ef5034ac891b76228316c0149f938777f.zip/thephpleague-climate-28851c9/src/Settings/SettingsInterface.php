<?php

namespace League\CLImate\Settings;

interface SettingsInterface
{
    /**
     * @return void
     */
    public function add();
}
