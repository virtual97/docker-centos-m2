With select queries you can select documents and/or facet counts from your Solr index. Solr select queries have lots of options. See the following pages for an intro:

-   <http://wiki.apache.org/solr/CommonQueryParameters>
-   <http://wiki.apache.org/solr/SearchHandler>
-   <http://wiki.apache.org/solr/SimpleFacetParameters>

