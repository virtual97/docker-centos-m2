var re=/[^A-Za-z0-9_\\]/
var string="Just a filler string";