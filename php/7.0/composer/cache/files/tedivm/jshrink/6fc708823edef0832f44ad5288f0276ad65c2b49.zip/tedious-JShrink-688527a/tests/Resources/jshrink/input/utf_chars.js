var π = Math.PI,
    ε = 1e-6,
    radians = π / 180,
    degrees = 180 / π;

function sgn(x) {


    var π = Math.PI;
    return x > 0 ? 1 : x < 0 ? -1 : 0;
}