(function(){
        (function(){
                return new Array(1, 2, 3);
        })();
        function Array(){};
})();
